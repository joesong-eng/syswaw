<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Log;
use App\Models\MachineData;
use App\Models\MachineAuthKey;
use App\Models\Machine;
use App\Models\Arcade;
use Illuminate\Support\Carbon;
use Illuminate\Http\JsonResponse;

class DataIngestionController extends Controller
{
    /**
     * 主方法：處理前端或定時任務的數據擷取請求。
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function ingestMqttData(Request $request): JsonResponse
    {
        $lockKey = 'data_ingestion_lock';
        $lockTimeout = 30; // 設置較長的鎖定時間，以確保處理完成

        // 嘗試獲取 Redis 鎖 (使用 SET NX EX 原子操作)
        $acquiredLock = Redis::set($lockKey, 'locked', 'EX', $lockTimeout, 'NX');

        if (!$acquiredLock) {
            Log::warning('DataIngestionController: 請求被鎖定，避免重複執行。', ['lockKey' => $lockKey]);
            return response()->json(['status' => 'warning', 'message' => '數據擷取正在處理中，請勿重複提交。'], 429);
        }

        try {
            $processedRecords = $this->processRedisStreamData();

            // 處理完成後釋放鎖
            Redis::del($lockKey);

            return response()->json([
                'status' => 'success',
                'message' => '數據擷取與寫入完成',
                'processed_count' => count($processedRecords),
                'details' => $processedRecords // 可以返回處理詳情
            ]);
        } catch (\Exception $e) {
            // 發生錯誤時也釋放鎖
            Redis::del($lockKey);
            Log::error('DataIngestionController: 數據擷取與寫入失敗', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'status' => 'error',
                'message' => '數據擷取與寫入失敗: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * 從 Redis Stream 獲取數據並寫入資料庫。
     *
     * @return array 處理後的記錄詳情
     */
    private function processRedisStreamData(): array
    {
        // 獲取所有以 'machine_data:' 開頭的 Key
        $keys = Redis::keys('machine_data:*');

        if (empty($keys)) {
            return [];
        }

        $processedData = [];
        foreach ($keys as $key) {
            $jsonData = Redis::get($key); // 從 Redis 獲取數據

            if (empty($jsonData)) {
                Log::warning('DataIngestionController: 從 Redis Key 獲取到空數據，跳過。', ['key' => $key]);
                // 考慮在這裡刪除空 Key，如果確定是無效數據
                // Redis::del($key);
                continue;
            }

            $decodedData = json_decode($jsonData, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                Log::warning('DataIngestionController: 無法從 Redis Key 解碼 JSON 數據.', ['key' => $key, 'jsonData' => $jsonData, 'jsonError' => json_last_error_msg()]);
                $processedData[] = [
                    'key' => $key,
                    'status' => 'json_decode_failed',
                    'error_message' => json_last_error_msg()
                ];
                continue;
            }

            $timestampFromPayload = $decodedData['timestamp'] ?? null;
            $isoTimestamp = null;

            if ($timestampFromPayload) {
                try {
                    $isoTimestamp = Carbon::parse($timestampFromPayload)->toIso8601String();
                } catch (\Exception $e) {
                    Log::warning('DataIngestionController: 無法解析數據 payload 中的時間戳，跳過記錄。', [
                        'key' => $key,
                        'timestamp' => $timestampFromPayload,
                        'error' => $e->getMessage(),
                    ]);
                    continue;
                }
            } else {
                Log::warning('DataIngestionController: 解碼數據 payload 中缺少時間戳字段，跳過記錄。', ['key' => $key, 'decodedData' => $decodedData]);
                continue;
            }

            // 獲取機台和認證金鑰信息
            $machineId = null;
            $arcadeId = null;
            $authKeyId = null;
            $machineType = null;
            $machineName = 'N/A';
            $authKeyString = 'N/A';

            $authKeyFromPayload = $decodedData['auth_key'] ?? null; // 從 payload 中獲取 auth_key

            if ($authKeyFromPayload) {
                $authKeyModel = MachineAuthKey::where('auth_key', $authKeyFromPayload) // 使用 auth_key 查詢
                    ->where('status', 'active')
                    ->latest('created_at')
                    ->first();

                if ($authKeyModel) {
                    $machine = Machine::where('id', $authKeyModel->machine_id)
                        ->where('is_active', true)
                        ->first();

                    if ($machine) {
                        $machineId = $machine->id;
                        $arcadeId = $machine->arcade_id;
                        $authKeyId = $authKeyModel->id;
                        $machineType = $machine->machine_type;
                        $machineName = $machine->name;
                        $authKeyString = $authKeyModel->auth_key;
                    } else {
                        Log::warning('DataIngestionController: 機台未找到或不活躍 for auth_key.', ['auth_key' => $authKeyFromPayload, 'machine_id' => $authKeyModel->machine_id]);
                    }
                } else {
                    Log::warning('DataIngestionController: 未找到活躍的 auth_key.', ['auth_key' => $authKeyFromPayload]);
                }
            } else {
                Log::warning('DataIngestionController: payload 中缺少 auth_key，無法進行機台查找.', ['key' => $key, 'decodedData' => $decodedData]);
            }

            // 額外檢查：基於 auth_key_id 和 timestamp 的重複判斷
            // 由於 Redis 中每個 Key 已經是最新數據，這裡的重複判斷主要用於防止數據庫層面的重複寫入
            if (
                $authKeyId && MachineData::where('auth_key_id', $authKeyId)
                ->where('timestamp', $isoTimestamp)
                ->exists()
            ) {
                Log::info('DataIngestionController: 基於 auth_key_id 和 timestamp 跳過重複記錄', ['auth_key_id' => $authKeyId, 'timestamp' => $isoTimestamp]);
                $processedData[] = [
                    'key' => $key,
                    'status' => 'skipped_duplicate_by_timestamp',
                    'message' => '重複記錄 (時間戳)'
                ];
                // 處理完畢後，從 Redis 中刪除該 Key，避免下次重複處理
                Redis::del($key);
                continue;
            }

            // 只有當找到有效的 machine_id, arcade_id, auth_key_id 時才嘗試寫入
            if ($machineId && $arcadeId && $authKeyId) {
                try {
                    MachineData::create([
                        'machine_id' => $machineId,
                        'arcade_id' => $arcadeId,
                        'auth_key_id' => $authKeyId,
                        'machine_type' => $machineType ?? ($decodedData['machine_type'] ?? 'unknown'),
                        'credit_in' => (int)($decodedData['credit_in'] ?? 0),
                        'ball_in' => (int)($decodedData['ball_in'] ?? 0),
                        'ball_out' => (int)($decodedData['ball_out'] ?? 0),
                        'coin_out' => (int)($decodedData['coin_out'] ?? 0),
                        'assign_credit' => (int)($decodedData['assign_credit'] ?? 0),
                        'settled_credit' => (int)($decodedData['settled_credit'] ?? 0),
                        'bill_denomination' => (int)($decodedData['bill_denomination'] ?? 0),
                        'error_code' => $decodedData['error_code'] ?? null,
                        'timestamp' => $isoTimestamp,
                        // 'redis_stream_id' => $recordId, // 不再儲存 Redis Stream ID
                    ]);
                    $processedData[] = [
                        'key' => $key,
                        'status' => 'saved_to_db',
                        'machine_name' => $machineName,
                        'auth_key' => $authKeyFromPayload,
                        'timestamp' => $isoTimestamp
                    ];
                    Log::info('DataIngestionController: 成功處理並儲存記錄', ['key' => $key, 'machine_id' => $machineId]);
                    // 處理完畢後，從 Redis 中刪除該 Key
                    Redis::del($key);
                } catch (\Exception $e) {
                    Log::error('DataIngestionController: 無法創建 MachineData 記錄', [
                        'error' => $e->getMessage(),
                        'key' => $key,
                        'data_payload' => $decodedData
                    ]);
                    $processedData[] = [
                        'key' => $key,
                        'status' => 'failed_to_save',
                        'error_message' => $e->getMessage()
                    ];
                }
            } else {
                Log::warning('DataIngestionController: 缺少必要的機台信息，無法儲存記錄。', ['key' => $key, 'authKeyFromPayload' => $authKeyFromPayload, 'decodedData' => $decodedData]);
                $processedData[] = [
                    'key' => $key,
                    'status' => 'missing_machine_info',
                    'message' => '缺少機台或認證金鑰信息'
                ];
            }
        }

        return $processedData;
    }

    /**
     * 從 Redis Key-Value 儲存獲取最新的 MQTT 數據，僅用於顯示，不寫入資料庫。
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getStreamMqttData(): JsonResponse
    {
        try {
            // 獲取所有以 'machine_data:' 開頭的 Key
            $keys = Redis::keys('machine_data:*');

            if (empty($keys)) {
                return response()->json([]);
            }

            $processedData = [];
            foreach ($keys as $key) {
                $jsonData = Redis::get($key); // 從 Redis 獲取數據

                if (empty($jsonData)) {
                    Log::warning('DataIngestionController: 從 Redis Key 獲取到空數據，跳過 (只讀模式)。', ['key' => $key]);
                    continue;
                }

                $decodedData = json_decode($jsonData, true);

                if (json_last_error() !== JSON_ERROR_NONE) {
                    Log::warning('DataIngestionController: 無法從 Redis Key 解碼 JSON 數據 (只讀模式).', ['key' => $key, 'jsonData' => $jsonData, 'jsonError' => json_last_error_msg()]);
                    $processedData[] = [
                        'key' => $key,
                        'status' => 'json_decode_failed',
                        'error_message' => json_last_error_msg()
                    ];
                    continue;
                }

                $timestampFromPayload = $decodedData['timestamp'] ?? null;
                $isoTimestamp = null;

                if ($timestampFromPayload) {
                    try {
                        $isoTimestamp = Carbon::parse($timestampFromPayload)->toIso8601String();
                    } catch (\Exception $e) {
                        Log::warning('DataIngestionController: 無法解析數據 payload 中的時間戳，跳過記錄 (只讀模式)。', [
                            'key' => $key,
                            'timestamp' => $timestampFromPayload,
                            'error' => $e->getMessage(),
                        ]);
                        continue;
                    }
                } else {
                    Log::warning('DataIngestionController: 解碼數據 payload 中缺少時間戳字段，跳過記錄 (只讀模式)。', ['key' => $key, 'decodedData' => $decodedData]);
                    continue;
                }

                $machineName = 'N/A';
                $authKeyString = 'N/A';
                $machineId = null;
                $arcadeId = null;
                $machineType = null;

                $authKeyFromPayload = $decodedData['auth_key'] ?? null; // 從 payload 中獲取 auth_key

                if ($authKeyFromPayload) {
                    $authKeyModel = MachineAuthKey::where('auth_key', $authKeyFromPayload) // 使用 auth_key 查詢
                        ->where('status', 'active')
                        ->latest('created_at')
                        ->first();

                    if ($authKeyModel) {
                        $machine = Machine::where('id', $authKeyModel->machine_id)
                            ->where('is_active', true)
                            ->first();

                        if ($machine) {
                            $machineName = $machine->name;
                            $machineId = $machine->id;
                            $arcadeId = $machine->arcade_id;
                            $machineType = $machine->machine_type;
                            $authKeyString = $authKeyModel->auth_key;
                        } else {
                            Log::warning('DataIngestionController: 機台未找到或不活躍 for auth_key (只讀模式).', ['auth_key' => $authKeyFromPayload, 'machine_id' => $authKeyModel->machine_id]);
                        }
                    } else {
                        Log::warning('DataIngestionController: 未找到活躍的 auth_key (只讀模式).', ['auth_key' => $authKeyFromPayload]);
                    }
                } else {
                    Log::warning('DataIngestionController: payload 中缺少 auth_key，無法進行機台查找 (只讀模式).', ['key' => $key, 'decodedData' => $decodedData]);
                }

                $processedData[] = [
                    'data' => $decodedData,
                    'timestamp' => $isoTimestamp,
                    'machine_name' => $machineName,
                    'auth_key_string' => $authKeyString,
                    'machine_id' => $machineId,
                    'arcade_id' => $arcadeId,
                    'machine_type' => $machineType,
                    'status' => 'read_only' // 標記為只讀數據
                ];
            }

            return response()->json($processedData);
        } catch (\Exception $e) {
            Log::error('DataIngestionController: 無法從 Redis 獲取最新的 MQTT 數據 (只讀模式)', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => '無法從 Redis 獲取數據'], 500);
        }
    }
}

<?php

namespace App\Providers;

use Illuminate\Support\Facades\Auth;
use App\Actions\Fortify\CreateNewUser;
use App\Actions\Fortify\ResetUserPassword;
use App\Actions\Fortify\UpdateUserPassword;
use App\Actions\Fortify\UpdateUserProfileInformation;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;
use Laravel\Fortify\Fortify;
// 新增這一行：引入 UpdatesUserProfileInformation 介面
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;
// 新增這一行：引入 UpdatesUserPasswords 介面
use Laravel\Fortify\Contracts\UpdatesUserPasswords;


class FortifyServiceProvider extends ServiceProvider
{

    public function boot(): void
    {
        // 自定義登入行為
        Fortify::authenticateUsing(function ($request) {
            $user = Auth::attempt([
                'email' => $request->email,
                'password' => $request->password,
            ]);

            return $user ? Auth::user() : null;
        });

        // 登入頁面
        Fortify::loginView(function () {
            return view('auth.login');
        });

        // 統一角色跳轉邏輯
        Fortify::redirects('login', fn() => $this->getRedirectPath());
        Fortify::redirects('email-verification', fn() => $this->getRedirectPath());

        // 綁定更新使用者個人資料的介面到你的實作
        $this->app->singleton(
            UpdatesUserProfileInformation::class,
            UpdateUserProfileInformation::class
        );


        // 綁定更新使用者密碼的介面到你的實作
        $this->app->singleton(
            UpdatesUserPasswords::class,
            UpdateUserPassword::class
        );
    }

    /**
     * 根據角色取得跳轉路徑
     *
     * @return string
     */
    private function getRedirectPath(): string
    {
        $user = Auth::user();

        if (!$user) {
            return route('home'); // 未登入用戶重定向到首頁
        }

        if ($user->hasRole('admin')) {
            return route('admin.dashboard');
        } elseif ($user->hasRole('arcade-owner')) {
            return route('arcade.dashboard'); // 修正路由名稱
        } elseif ($user->hasRole('arcade-staff')) {
            return route('arcade.dashboard'); // 修正路由名稱
        } elseif ($user->hasRole('machine-owner')) {
            return route('machine.dashboard'); // 修正路由名稱
        } elseif ($user->hasRole('machine-manager')) {
            return route('machine.dashboard'); // 修正路由名稱
        } elseif ($user->hasRole('member')) {
            return route('member.dashboard');
        } elseif ($user->hasRole('user')) {
            return route('user.dashboard');
        }

        return route('home'); // 預設跳轉
    }

    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }


    // public function boot(): void
    // {
    //     Fortify::createUsersUsing(CreateNewUser::class);
    //     Fortify::updateUserProfileInformationUsing(UpdateUserProfileInformation::class);
    //     Fortify::updateUserPasswordsUsing(UpdateUserPassword::class);
    //     Fortify::resetUserPasswordsUsing(ResetUserPassword::class);

    //     RateLimiter::for('login', function (Request $request) {
    //         $throttleKey = Str::transliterate(Str::lower($request->input(Fortify::username())) . '|' . $request->ip());

    //         return Limit::perMinute(5)->by($throttleKey);
    //     });

    //     RateLimiter::for('two-factor', function (Request $request) {
    //         return Limit::perMinute(5)->by($request->session()->get('login.id'));
    //     });
    // }


    /**
     * Bootstrap any application services.
     */
}

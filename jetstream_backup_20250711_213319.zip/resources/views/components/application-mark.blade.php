  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="30" height="30">
      <circle cx="100" cy="100" r="90" stroke="gray" stroke-width="10" fill="none" />
      <polygon points="100,20 170,140 30,140" stroke="gray" stroke-width="10" fill="none" />
      <polygon points="100,180 170,60 30,60" stroke="gray" stroke-width="10" fill="none" />
    </svg>

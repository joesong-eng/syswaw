<div id="{{ $id }}" class="ctrl-overlay hidden">
    <div class="spinner"></div>
</div>

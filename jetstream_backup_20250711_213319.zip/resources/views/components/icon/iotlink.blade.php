<svg width="120" height="60" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100">
    <!-- 背景透明 -->
    <rect width="100%" height="100%" fill="none"/>
  
    <!-- 小寫 i -->
    <text x="10" y="70" font-family="Arial" font-size="40" fill="black">i</text>
  
    <!-- 第一個紅色圓點 (o) -->
    <circle cx="40" cy="50" r="15" fill="red"/>
  
    <!-- T 和 L 重合 -->
    <text x="70" y="70" font-family="Arial" font-size="40" fill="black">T</text>
    <text x="76" y="70" font-family="Arial" font-size="40" fill="black" fill-opacity="0.5">L</text>
    <!-- 調整 TL 寬度為 1.5 倍字寬 -->
    {{-- <rect x="70" y="0" width="90" height="100" fill="none" stroke="none"/> --}}
  
    <!-- 大寫 I -->
    <text x="80" y="70" font-family="Arial" font-size="40" fill="black">I</text>
  
    <!-- N 和 K 重合 -->
    <text x="100" y="70" font-family="Arial" font-size="40" fill="black">N</text>
    <text x="120" y="70" font-family="Arial" font-size="40" fill="black" fill-opacity="0.5">K</text>
    <!-- 調整 NK 寬度為 1.5 倍字寬 -->
    {{-- <rect x="100" y="0" width="90" height="100" fill="none" stroke="none"/> --}}
  
    <!-- 間距控制：每個字母間距約 30px，TL 和 NK 間距適當拉寬 -->
  </svg>
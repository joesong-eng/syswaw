<svg fill="currentcolor" width="1.5rem" height="1.5rem" viewBox="0 0 32 32" id="icon" xmlns="http://www.w3.org/2000/svg"
    class="text-dark dark:text-white ">
    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
    <g id="SVGRepo_iconCarrier">
        <defs>
            <style>
                .cls-1 {
                    fill: none;
                }
            </style>
        </defs>
        <title>user--role</title>
        <polygon points="28.07 21 22 15 28.07 9 29.5 10.41 24.86 15 29.5 19.59 28.07 21"></polygon>
        <path d="M22,30H20V25a5,5,0,0,0-5-5H9a5,5,0,0,0-5,5v5H2V25a7,7,0,0,1,7-7h6a7,7,0,0,1,7,7Z"></path>
        <path d="M12,4A5,5,0,1,1,7,9a5,5,0,0,1,5-5m0-2a7,7,0,1,0,7,7A7,7,0,0,0,12,2Z"></path>
        <rect id="_Transparent_Rectangle_" data-name="<Transparent Rectangle>" class="text-dark cls-1" width="32"
            height="32"></rect>
    </g>
</svg>

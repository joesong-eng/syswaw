@php
    extract($extraData ?? []);
@endphp

{!! $getSvg($classes ?? 'h-6 w-6') !!}
<?php
return [
    'redis_control' => 'redis_ctrlTcpServer', //redis 頻道
    'reverb_respone' => 'reverb_tcpSvRespone', //reverb 頻道
    'capture' => 'channel_captureTcpData',
];

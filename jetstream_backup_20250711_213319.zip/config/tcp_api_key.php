<?php
return [
    'api_key' => env('TCP_API_KEY'),
];
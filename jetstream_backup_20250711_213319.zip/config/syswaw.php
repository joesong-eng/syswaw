<?php
return [
    'tcp_api_key' => env('TCP_API_KEY', 'default123'),
];